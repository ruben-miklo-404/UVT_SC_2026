#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#define ROUNDS 27
#define ROR(x, r) ((x >> r) | (x << (32 - r)))
#define ROL(x, r) ((x << r) | (x >> (32 - r)))
#define R(x, y, k) (x = ROR(x, 8), x += y, x ^= k, y = ROL(y, 3), y ^= x)
#define RR(x, y, k) (y ^= x, y = ROR(y, 3), x ^= k, x -= y, x = ROL(x, 8))

void speck_encrypt_block(uint32_t block_words[2], const uint32_t raw_key[4]) 
{
    uint32_t y_word = block_words[0];
    uint32_t x_word = block_words[1];
    uint32_t key_b = raw_key[0];
    uint32_t key_a[3];

    key_a[0] = raw_key[1]; 
    key_a[1] = raw_key[2]; 
    key_a[2] = raw_key[3];

    for (int round = 0; round < ROUNDS; round++) 
    {
        R(x_word, y_word, key_b);
        uint32_t next_b = key_b;
        R(key_a[round % 3], next_b, round);
        key_b = next_b;
    }

    block_words[0] = y_word; 
    block_words[1] = x_word;
}

void speck_decrypt_block(uint32_t block_words[2], const uint32_t raw_key[4]) 
{
    uint32_t y_word = block_words[0];
    uint32_t x_word = block_words[1];
    uint32_t round_schedule[ROUNDS];
    uint32_t key_b = raw_key[0];
    uint32_t key_a[3];

    key_a[0] = raw_key[1]; 
    key_a[1] = raw_key[2]; 
    key_a[2] = raw_key[3];

    for (int round = 0; round < ROUNDS; round++) 
    {
        round_schedule[round] = key_b;
        uint32_t next_b = key_b;
        R(key_a[round % 3], next_b, round);
        key_b = next_b;
    }

    for (int round = ROUNDS - 1; round >= 0; round--) 
    {
        RR(x_word, y_word, round_schedule[round]);
    }

    block_words[0] = y_word; 
    block_words[1] = x_word;
}

void process_file(const char* input_path, const char* output_path, uint32_t expanded_key[4], int operation_mode) 
{
    FILE *source_file = fopen(input_path, "rb");
    FILE *destination_file = fopen(output_path, "wb");

    if (!source_file || !destination_file) 
    {
        fprintf(stderr, "Error opening target files.\n");
        exit(1);
    }

    size_t out_len = 0;
    int has_meta = 0;

    if (operation_mode == 1) 
    {
        char meta_path[512];
        snprintf(meta_path, sizeof(meta_path), "%s.meta", input_path);
        FILE* meta = fopen(meta_path, "r");
        
        if (meta) 
        {
            if (fscanf(meta, "%lu", &out_len) == 1) 
            {
                has_meta = 1;
            }
            fclose(meta);
            remove(meta_path);
        }
    } 
    else 
    {
        fseek(source_file, 0, SEEK_END);
        size_t in_len = ftell(source_file);
        fseek(source_file, 0, SEEK_SET);

        char meta_path[512];
        snprintf(meta_path, sizeof(meta_path), "%s.meta", output_path);
        FILE* meta = fopen(meta_path, "w");
        
        if (meta) 
        {
            fprintf(meta, "%lu", in_len);
            fclose(meta);
        }
    }

    uint32_t data_buffer[2];
    size_t bytes_read;
    size_t bytes_written = 0;

    while ((bytes_read = fread(data_buffer, 1, 8, source_file)) > 0) 
    {
        if (bytes_read < 8) 
        {
            memset((uint8_t*)data_buffer + bytes_read, 0, 8 - bytes_read);
        }

        if (operation_mode == 0) 
        { 
            speck_encrypt_block(data_buffer, expanded_key);
            fwrite(data_buffer, 1, 8, destination_file);
        } 
        else 
        {         
            speck_decrypt_block(data_buffer, expanded_key);
            size_t chunk = 8;
            
            if (has_meta && (bytes_written + 8 > out_len)) 
            {
                chunk = out_len - bytes_written;
            }
            
            fwrite(data_buffer, 1, chunk, destination_file);
            bytes_written += chunk;
            
            if (has_meta && bytes_written >= out_len) 
            {
                break;
            }
        }
    }

    fclose(source_file);
    fclose(destination_file);
}

int main(int argument_count, char** argument_vector) 
{
    if (argument_count != 7) 
    {
        printf("Usage: %s -e/-d -input <file> <key_int> -output <file>\n", argument_vector[0]);
        return 3;
    }

    char *input_path = NULL, *output_path = NULL, *mode_flag = NULL;
    uint32_t internal_key[4] = {0};

    for (int i = 1; i < argument_count; i++) 
    {
        if (strcmp(argument_vector[i], "-e") == 0 || strcmp(argument_vector[i], "-d") == 0) 
        {
            mode_flag = argument_vector[i];
        } 
        else if (strcmp(argument_vector[i], "-input") == 0 && i + 1 < argument_count) 
        {
            input_path = argument_vector[++i];
        } 
        else if (strcmp(argument_vector[i], "-output") == 0 && i + 1 < argument_count) 
        {
            output_path = argument_vector[++i];
        } 
        else 
        {
            uint32_t setup_seed = (uint32_t)atoi(argument_vector[i]);
            internal_key[0] = setup_seed; 
            internal_key[1] = setup_seed; 
            internal_key[2] = setup_seed; 
            internal_key[3] = setup_seed;
        }
    }

    if (!mode_flag || !input_path || !output_path)
    {
        fprintf(stderr, "Invalid parameters missing flags.\n");
        return 1;
    }

    int operation_mode = (strcmp(mode_flag, "-e") == 0) ? 0 : 1;
    process_file(input_path, output_path, internal_key, operation_mode);

    return 0;
}