#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <gmp.h>

#define BUFFER_SIZE (1024 * 1024) 
#define KEY_BYTES 128            
#define SYMMETRIC_KEY_WORDS 4

const char* P_HEX = 
    "FFFFFFFFFFFFFFFFC90FDAA22168C234C4C6628B80DC1CD1"
    "29024E088A67CC74020BBEA63B139B22514A08798E3404DD"
    "EF9519B3CD3A431B302B0A6DF25F14374FE1356D6D51C245"
    "E485B576625E7EC6F44C42E9A637ED6B0BFF5CB6F406B7ED"
    "EE386BFB5A899FA5AE9F24117C4B1FE649286651ECE65381"
    "FFFFFFFFFFFFFFFF";

const char* G_STR = "2"; 

uint32_t deterministic_rand(uint64_t *state) 
{
    *state = (*state * 6364136223846793005ULL + 1442695040888963407ULL);
    return (uint32_t)(*state >> 32);
}

void get_deterministic_ephemeral(mpz_t out, mpz_t max_val, uint64_t *state) 
{
    gmp_randstate_t rand_state;
    gmp_randinit_default(rand_state);
    *state = (*state * 6364136223846793005ULL + 1442695040888963407ULL);
    gmp_randseed_ui(rand_state, (unsigned long)(*state));
    mpz_urandomm(out, rand_state, max_val);
    mpz_add_ui(out, out, 2); 
    gmp_randclear(rand_state);
}

void tea_encrypt_block(uint32_t text_block[2], const uint32_t cipher_key[4]) 
{
    uint32_t left_word = text_block[0];
    uint32_t right_word = text_block[1];
    uint32_t accumulator = 0;
    uint32_t delta_constant = 0x9e3779b9;

    for (int round = 0; round < 32; round++) 
    {
        accumulator += delta_constant;
        left_word += ((right_word << 4) + cipher_key[0]) ^ (right_word + accumulator) ^ ((right_word >> 5) + cipher_key[1]);
        right_word += ((left_word << 4) + cipher_key[2]) ^ (left_word + accumulator) ^ ((left_word >> 5) + cipher_key[3]);
    }
    
    text_block[0] = left_word; 
    text_block[1] = right_word;
}

void tea_decrypt_block(uint32_t text_block[2], const uint32_t cipher_key[4]) 
{
    uint32_t left_word = text_block[0];
    uint32_t right_word = text_block[1];
    uint32_t delta_constant = 0x9e3779b9;
    uint32_t accumulator = delta_constant * 32;

    for (int round = 0; round < 32; round++) 
    {
        right_word -= ((left_word << 4) + cipher_key[2]) ^ (left_word + accumulator) ^ ((left_word >> 5) + cipher_key[3]);
        left_word -= ((right_word << 4) + cipher_key[0]) ^ (right_word + accumulator) ^ ((right_word >> 5) + cipher_key[1]);
        accumulator -= delta_constant;
    }
    
    text_block[0] = left_word; 
    text_block[1] = right_word;
}

void process_file(const char* input_path, const char* output_path, uint64_t user_key_seed, int operation_mode) 
{
    FILE *source_file = fopen(input_path, "rb");
    FILE *destination_file = fopen(output_path, "wb");

    if (!source_file || !destination_file) 
    {
        fprintf(stderr, "Fatal Error: Unable to open file streams.\n");
        exit(1);
    }

    uint64_t prng_state = user_key_seed;

    mpz_t p, g, private_key, public_key, ephemeral_key, shared_secret;
    mpz_t cipher_part1, cipher_part2, key_mat_mpz, max_ephemeral;
    
    mpz_init_set_str(p, P_HEX, 16);
    mpz_init_set_str(g, G_STR, 10);
    mpz_init(private_key); 
    mpz_init(public_key); 
    mpz_init(ephemeral_key);
    mpz_init(shared_secret); 
    mpz_init(cipher_part1); 
    mpz_init(cipher_part2);
    mpz_init(key_mat_mpz); 
    mpz_init(max_ephemeral);
    mpz_sub_ui(max_ephemeral, p, 3);

    gmp_randstate_t setup_state;
    gmp_randinit_default(setup_state);
    gmp_randseed_ui(setup_state, (unsigned long)user_key_seed);
    mpz_urandomm(private_key, setup_state, max_ephemeral);
    mpz_add_ui(private_key, private_key, 2);
    mpz_powm(public_key, g, private_key, p);
    gmp_randclear(setup_state);

    uint32_t tea_key[SYMMETRIC_KEY_WORDS];
    uint8_t block_c1[KEY_BYTES];
    uint8_t block_c2[KEY_BYTES];
    uint8_t *io_buffer = malloc(BUFFER_SIZE);

    if (!io_buffer) 
    {
        fprintf(stderr, "Memory allocation error.\n");
        exit(1);
    }

    if (operation_mode == 0) 
    {
        for (int i = 0; i < SYMMETRIC_KEY_WORDS; i++) 
        {
            tea_key[i] = deterministic_rand(&prng_state);
        }

        mpz_import(key_mat_mpz, SYMMETRIC_KEY_WORDS * sizeof(uint32_t), 1, 1, 1, 0, tea_key);
        
        get_deterministic_ephemeral(ephemeral_key, max_ephemeral, &prng_state);
        mpz_powm(cipher_part1, g, ephemeral_key, p);
        mpz_powm(shared_secret, public_key, ephemeral_key, p);
        mpz_mul(cipher_part2, key_mat_mpz, shared_secret);
        mpz_mod(cipher_part2, cipher_part2, p);

        memset(block_c1, 0, KEY_BYTES);
        memset(block_c2, 0, KEY_BYTES);
        size_t w1, w2;
        mpz_export(block_c1, &w1, 1, 1, 1, 0, cipher_part1);
        mpz_export(block_c2, &w2, 1, 1, 1, 0, cipher_part2);
        
        if (w1 < KEY_BYTES && w1 > 0) 
        { 
            memmove(block_c1 + (KEY_BYTES - w1), block_c1, w1); 
            memset(block_c1, 0, KEY_BYTES - w1); 
        }
        
        if (w2 < KEY_BYTES && w2 > 0) 
        { 
            memmove(block_c2 + (KEY_BYTES - w2), block_c2, w2); 
            memset(block_c2, 0, KEY_BYTES - w2); 
        }

        fwrite(block_c1, 1, KEY_BYTES, destination_file);
        fwrite(block_c2, 1, KEY_BYTES, destination_file);

        size_t bytes_read;
        while ((bytes_read = fread(io_buffer, 1, BUFFER_SIZE, source_file)) > 0) 
        {
            size_t padded_length = ((bytes_read + 7) / 8) * 8;
            if (padded_length > bytes_read) 
            {
                memset(io_buffer + bytes_read, (uint8_t)(padded_length - bytes_read), padded_length - bytes_read);
            }

            for (size_t i = 0; i < padded_length; i += 8) 
            {
                tea_encrypt_block((uint32_t*)(io_buffer + i), tea_key);
            }
            fwrite(io_buffer, 1, padded_length, destination_file);
        }
    } 
    else 
    { 
        if (fread(block_c1, 1, KEY_BYTES, source_file) != KEY_BYTES || fread(block_c2, 1, KEY_BYTES, source_file) != KEY_BYTES) 
        {
            fprintf(stderr, "Error: Invalid asymmetric header footprint.\n");
            exit(1);
        }

        mpz_import(cipher_part1, KEY_BYTES, 1, 1, 1, 0, block_c1);
        mpz_import(cipher_part2, KEY_BYTES, 1, 1, 1, 0, block_c2);

        get_deterministic_ephemeral(ephemeral_key, max_ephemeral, &prng_state);
        mpz_powm(shared_secret, cipher_part1, private_key, p);
        mpz_invert(shared_secret, shared_secret, p);
        mpz_mul(key_mat_mpz, cipher_part2, shared_secret);
        mpz_mod(key_mat_mpz, key_mat_mpz, p);

        uint8_t decrypted_key_bytes[SYMMETRIC_KEY_WORDS * sizeof(uint32_t)];
        size_t exported_bytes;
        memset(decrypted_key_bytes, 0, sizeof(decrypted_key_bytes));
        mpz_export(decrypted_key_bytes, &exported_bytes, 1, 1, 1, 0, key_mat_mpz);

        if (exported_bytes < sizeof(decrypted_key_bytes)) 
        {
            memmove(decrypted_key_bytes + (sizeof(decrypted_key_bytes) - exported_bytes), decrypted_key_bytes, exported_bytes);
            memset(decrypted_key_bytes, 0, sizeof(decrypted_key_bytes) - exported_bytes);
        }
        memcpy(tea_key, decrypted_key_bytes, sizeof(tea_key));

        size_t bytes_read;
        while ((bytes_read = fread(io_buffer, 1, BUFFER_SIZE, source_file)) > 0) 
        {
            for (size_t i = 0; i < bytes_read; i += 8) 
            {
                tea_decrypt_block((uint32_t*)(io_buffer + i), tea_key);
            }
            
            long current_pos = ftell(source_file);
            fseek(source_file, 0, SEEK_END);
            long end_pos = ftell(source_file);
            fseek(source_file, current_pos, SEEK_SET);

            if (current_pos == end_pos) 
            {
                uint8_t padding_value = io_buffer[bytes_read - 1];
                if (padding_value > 0 && padding_value <= 8) 
                {
                    bytes_read -= padding_value;
                }
            }
            
            if (bytes_read > 0) 
            {
                fwrite(io_buffer, 1, bytes_read, destination_file);
            }
        }
    }

    free(io_buffer);
    mpz_clears(p, g, private_key, public_key, ephemeral_key, shared_secret, cipher_part1, cipher_part2, key_mat_mpz, max_ephemeral, NULL);
    fclose(source_file); 
    fclose(destination_file);
}

int main(int argc, char** argv) 
{
    if (argc != 7) 
    {
        printf("Usage: %s -e/-d -input <file> <key_seed> -output <file>\n", argv[0]);
        return 3;
    }

    char *in_p = NULL, *out_p = NULL, *mode = NULL;
    uint64_t seed = 0;

    for (int i = 1; i < argc; i++) 
    {
        if (strcmp(argv[i], "-e") == 0 || strcmp(argv[i], "-d") == 0) 
        {
            mode = argv[i];
        }
        else if (strcmp(argv[i], "-input") == 0 && i + 1 < argc) 
        {
            in_p = argv[++i];
        }
        else if (strcmp(argv[i], "-output") == 0 && i + 1 < argc) 
        {
            out_p = argv[++i];
        }
        else 
        {
            seed = strtoull(argv[i], NULL, 10);
        }
    }

    if (!mode || !in_p || !out_p) 
    {
        fprintf(stderr, "Error: Missing operational script flags.\n");
        return 1;
    }

    int op = (strcmp(mode, "-e") == 0) ? 0 : 1;
    process_file(in_p, out_p, seed, op);
    return 0;
}