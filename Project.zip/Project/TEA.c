#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

void tea_encrypt_block(uint32_t text_block[2], const uint32_t cipher_key[4]) 
{
    uint32_t left_word = text_block[0];
    uint32_t right_word = text_block[1];
    uint32_t accumulator = 0;
    uint32_t delta_constant = 0x9e3779b9;

    for (int round = 0; round < 32; round++) 
    {
        accumulator += delta_constant;
        left_word += ((right_word << 4) + cipher_key[0]) ^ (right_word + accumulator) ^ ((right_word >> 5) + cipher_key[1]);
        right_word += ((left_word << 4) + cipher_key[2]) ^ (left_word + accumulator) ^ ((left_word >> 5) + cipher_key[3]);
    }
    
    text_block[0] = left_word; 
    text_block[1] = right_word;
}

void tea_decrypt_block(uint32_t text_block[2], const uint32_t cipher_key[4]) 
{
    uint32_t left_word = text_block[0];
    uint32_t right_word = text_block[1];
    uint32_t delta_constant = 0x9e3779b9;
    uint32_t accumulator = delta_constant * 32;

    for (int round = 0; round < 32; round++) 
    {
        right_word -= ((left_word << 4) + cipher_key[2]) ^ (left_word + accumulator) ^ ((left_word >> 5) + cipher_key[3]);
        left_word -= ((right_word << 4) + cipher_key[0]) ^ (right_word + accumulator) ^ ((right_word >> 5) + cipher_key[1]);
        accumulator -= delta_constant;
    }
    
    text_block[0] = left_word; 
    text_block[1] = right_word;
}

void process_file(const char* input_path, const char* output_path, uint32_t runtime_key[4], int operation_mode) 
{
    FILE *source_file = fopen(input_path, "rb");
    FILE *destination_file = fopen(output_path, "wb");

    if (!source_file || !destination_file) 
    {
        fprintf(stderr, "Fatal: Unable to open file streams.\n");
        exit(1);
    }

    uint32_t working_block[2];
    size_t bytes_read;

    if (operation_mode == 0) 
    {
        while ((bytes_read = fread(working_block, 1, 8, source_file)) > 0) 
        {
            if (bytes_read < 8) 
            {
                uint8_t total_padding = (uint8_t)(8 - bytes_read);
                memset((uint8_t*)working_block + bytes_read, total_padding, total_padding);
                tea_encrypt_block(working_block, runtime_key);
                fwrite(working_block, 1, 8, destination_file);
                bytes_read = 0;
                break;
            }
            
            tea_encrypt_block(working_block, runtime_key);
            fwrite(working_block, 1, 8, destination_file);
        }

        if (bytes_read == 0) 
        {
            memset(working_block, 8, 8);
            tea_encrypt_block(working_block, runtime_key);
            fwrite(working_block, 1, 8, destination_file);
        }
    } 
    else 
    {
        uint32_t stash_block[2];
        int pipeline_ready = 0;

        while ((bytes_read = fread(working_block, 1, 8, source_file)) > 0) 
        {
            tea_decrypt_block(working_block, runtime_key);

            if (pipeline_ready) 
            {
                fwrite(stash_block, 1, 8, destination_file);
            }

            memcpy(stash_block, working_block, 8);
            pipeline_ready = 1;
        }

        if (pipeline_ready) 
        {
            uint8_t strip_count = ((uint8_t*)stash_block)[7];
            if (strip_count > 0 && strip_count <= 8) 
            {
                size_t payload_len = 8 - strip_count;
                if (payload_len > 0) 
                {
                    fwrite(stash_block, 1, payload_len, destination_file);
                }
            } 
            else 
            {
                fwrite(stash_block, 1, 8, destination_file);
            }
        }
    }

    fclose(source_file);
    fclose(destination_file);
}

int main(int argument_count, char** argument_vector) 
{
    if (argument_count != 7) 
    {
        printf("Usage: %s -e/-d -input <file> <key> -output <file>\n", argument_vector[0]);
        return 3;
    }

    char *input_path = NULL, *output_path = NULL, *mode_flag = NULL;
    uint32_t internal_key[4] = {0};

    for (int i = 1; i < argument_count; i++) 
    {
        if (strcmp(argument_vector[i], "-e") == 0 || strcmp(argument_vector[i], "-d") == 0) 
        {
            mode_flag = argument_vector[i];
        } 
        else if (strcmp(argument_vector[i], "-input") == 0 && i + 1 < argument_count) 
        {
            input_path = argument_vector[++i];
        } 
        else if (strcmp(argument_vector[i], "-output") == 0 && i + 1 < argument_count) 
        {
            output_path = argument_vector[++i];
        } 
        else 
        {
            uint32_t translation_seed = (uint32_t)atoi(argument_vector[i]);
            internal_key[0] = translation_seed; 
            internal_key[1] = translation_seed; 
            internal_key[2] = translation_seed; 
            internal_key[3] = translation_seed;
        }
    }

    if (!mode_flag || !input_path || !output_path)
    {
        fprintf(stderr, "Error: Missing required execution arguments.\n");
        return 1;
    }

    int operation_mode = (strcmp(mode_flag, "-e") == 0) ? 0 : 1;
    process_file(input_path, output_path, internal_key, operation_mode);

    return 0;
}